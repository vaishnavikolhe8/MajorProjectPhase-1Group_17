document.querySelector('form').addEventListener('submit', function(event) {
  event.preventDefault();  // Prevent the form from refreshing the page

  const song = document.getElementById('song').value;
  const numRecommendations = document.getElementById('num_recommendations').value;

  // Make a POST request to the backend to get recommendations
  fetch('/recommend', {
      method: 'POST',
      body: new URLSearchParams({
          'song': song,
          'num_recommendations': numRecommendations
      }),
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      }
  })
  .then(response => response.json())
  .then(data => {
      const recommendationList = document.getElementById('recommendation-list');
      recommendationList.innerHTML = '';  // Clear previous recommendations

      if (data.error) {
          recommendationList.innerHTML = `<li>${data.error}</li>`;
      } else {
          data.recommendations.forEach(recommendation => {
              const listItem = document.createElement('li');
              listItem.innerHTML = `${recommendation.song} by ${recommendation.artist} (Similarity: ${recommendation.similarity})`;
              recommendationList.appendChild(listItem);
          });
      }
  })
  .catch(error => {
      console.error('Error:', error);
  });
});
