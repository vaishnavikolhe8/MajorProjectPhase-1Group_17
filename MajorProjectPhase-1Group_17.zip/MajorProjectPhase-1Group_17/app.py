import pandas as pd
from flask import Flask, render_template, request, jsonify
from recommend import ContentBasedRecommender
import pickle

app = Flask(__name__)

# Load dataset and model (Pre-trained similarities)
songs = pd.read_csv('songdata.csv')
songs = songs.sample(n=5000).drop('link', axis=1).reset_index(drop=True)  # Resample 5000 songs
songs['text'] = songs['text'].str.replace(r'\n', '')  # Clean lyrics

# Load precomputed cosine similarities
with open('similarities.pkl', 'rb') as file:
    similarities = pickle.load(file)

# Prepare the recommender
recommender = ContentBasedRecommender(similarities)

@app.route('/')
def home():
    # Prepare list of song names for dropdown in frontend
    song_names = songs['song'].tolist()
    return render_template('index.html', song_names=song_names)

@app.route('/recommend', methods=['POST'])
def recommend():
    song_name = request.form['song']
    num_recommendations = int(request.form['num_recommendations'])

    # Check if the song exists in the dataset
    if song_name not in similarities:
        return jsonify({'error': 'Song not found in the dataset'}), 400

    # Get recommendations from the model
    recommendations = recommender.recommend({'song': song_name, 'number_songs': num_recommendations})

    return jsonify({'recommendations': recommendations})

if __name__ == "__main__":
    app.run(debug=True)
